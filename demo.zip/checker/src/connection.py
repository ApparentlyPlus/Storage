import functools

from typing import Callable, Protocol


class Connectable(Protocol):
    """A protocol prooviding connection and disconnection methods."""

    def connect(self):
        """Ensures a connection is established."""
        pass

    def disconnect(self):
        """Terminates the connection if one is established."""
        pass


def connected(method: Callable) -> Callable:
    """Wraps a method in a Connectable type so that connect() is called before
    the method body and disconnect() is called after, even if an exception occurs."""
    @functools.wraps(method)
    def wrapper(self: Connectable, *args, **kwargs):
        try:
            self.connect()
            return method(self, *args, **kwargs)
        finally:
            self.disconnect()
    return wrapper