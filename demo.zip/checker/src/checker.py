from ctf_gameserver.checkerlib import *
from ctf_gameserver import checkerlib
from checksupport import *
from typing import Tuple
import logging
import string
import random
import hashlib
from pwn import remote

CHECKER_ENTROPY_SECRET_SEED = 'some_random_seed_to_generate_data'
ALNUM = string.ascii_letters + string.digits

class NotescatChecker(RandomChecksMixin, BaseChecker):
	checks = RandomScheduler()
	def __init__(self, ip: str, team: int):
		RandomChecksMixin.__init__(self, self.checks)
		BaseChecker.__init__(self, ip, team)
		self.cur_tick = 0
		self.r = None
		self.tokens = {}

	@ExceptionContext('connection error', CheckResult.DOWN)
	def connect(self):
		if self.r is None:
			self.r = remote(self.ip, 4242)

	def disconnect(self):
		self.r.close()
		self.r = None

	@ExceptionContext('connection interrupted during login', CheckResult.DOWN)
	def login(self, username, pw):
		
		self.r.sendline(b'1')
		self.r.recvuntil(b'username:', drop=True)
		self.r.sendline(username.encode())
		self.r.recvuntil(b'password:', drop=True)
		self.r.sendline(pw.encode())

	@ExceptionContext('connection interrupted during registration', CheckResult.DOWN)
	def register(self, username, pw, token):
		self.r.sendline(b'2')
		self.r.recvuntil(b'username:', drop=True)
		self.r.sendline(username.encode())
		self.r.recvuntil(b'password:', drop=True)
		self.r.sendline(pw.encode())
		self.r.recvuntil(b'token:', drop=True)
		self.r.sendline(token.encode())

	@ExceptionContext('connection interrupted during password reset', CheckResult.DOWN)
	def reset_pw(self, username, token, new_pw):
		
		self.r.sendline(b'3')
		self.r.recvuntil(b'username:', drop=True)
		self.r.sendline(username.encode())
		self.r.recvuntil(b'token:', drop=True)
		self.r.sendline(token.encode())
		self.r.recvuntil(b'new password:', drop=True)
		self.r.sendline(new_pw.encode())
		

	@ExceptionContext('connection interrupted during note creation', CheckResult.DOWN)
	def create_note(self, name, content):
		self.r.sendline(b'1')
		self.r.recvuntil(b'Name:', drop=True)
		self.r.sendline(name.encode())
		self.r.recvuntil(b'Content:', drop=True)
		self.r.sendline(content.encode())

	@ExceptionContext('connection interrupted during note creation', CheckResult.DOWN)
	def open_note(self, name):
		
		self.r.sendline(b'2')
		self.r.recvuntil(b'Name:', drop=True)
		self.r.sendline(name)
		self.r.recvuntil(b'Content: ', drop=True)
		
		content = self.r.readline()

		return content.decode().strip()
	
	def generate_account(self, flag, ukey, pkey, tkey):
		randomGen = RandomGenerator(flag + CHECKER_ENTROPY_SECRET_SEED)
		
		randomGen.set_key(ukey)
		username = ''.join(randomGen.choices(ALNUM, k=6))
		
		randomGen.set_key(pkey)
		pw = ''.join(randomGen.choices(ALNUM, k=16))
		
		randomGen.set_key(tkey)
		token = ''.join(randomGen.choices(ALNUM, k=16))
		
		return username, pw, token
	
	def generate_note(self, flag, nkey, ckey):
		randomGen = RandomGenerator(flag + CHECKER_ENTROPY_SECRET_SEED)

		randomGen.set_key(nkey)
		note_name = ''.join(randomGen.choices(ALNUM, k=8))

		randomGen.set_key(ckey)
		content = ''.join(randomGen.choices(ALNUM, k=16))

		return note_name, content


	@ExceptionContext('error placing flag', CheckResult.FAULTY, toplevel=True)
	def place_flag(self, tick):
		flag = checkerlib.get_flag(tick)
		self.cur_tick = tick
		username, pw, token = self.generate_account(flag, 'flag-user', 'flag-password', 'flag-token')

		note_name, _ = self.generate_note(flag, 'flag-note', '')
		
		self.connect()

		self.r.recvuntil(b'>', drop=True)
		self.register(username, pw, token)
		
		self.r.recvuntil(b'>', drop=True)
		self.login(username,pw)

		self.r.recvuntil(b'>', drop=True)
		self.create_note(note_name, flag)

		self.disconnect()
		print(username)
		checkerlib.set_flagid(f'{username}:{note_name}')

		return checkerlib.CheckResult.OK, ''



	@ExceptionContext('error checking flag', CheckResult.FLAG_NOT_FOUND, toplevel=True)
	def check_flag(self, tick):
		flag = checkerlib.get_flag(tick)
		note_name = checkerlib.get_flagid(tick).split(':')[1]
		username, pw, token = self.generate_account(flag, 'flag-user', 'flag-password', 'flag-token')
		self.connect()
		self.r.recvuntil(b'>', drop=True)
		
		self.login(username, pw)

		resp = self.r.recvuntil(b'>', drop=True)
		if b'# [Authenticated]\n# Select an action:\n1. New note\n2. Open note\n3. Logout\n' not in resp:
			self.reset_pw(username, token, pw)
			self.r.recvuntil(b'>', drop=True)
			self.login(username, pw)
			resp = self.r.recvuntil(b'>', drop=True)
			self.disconnect()
			if b'# [Authenticated]\n# Select an action:\n1. New note\n2. Open note\n3. Logout\n' not in resp:
				return checkerlib.CheckResult.FAULTY, 'Could not login with valid credentials!'


		content = self.open_note(note_name)
		self.disconnect()

		if content != flag:
			return checkerlib.CheckResult.FLAG_NOT_FOUND, 'The flag was not found!'

		return checkerlib.CheckResult.OK, ''


	@checks.task('register')
	@ExceptionContext('error registering account', CheckResult.FAULTY, toplevel=True)
	def check_registration(self):
		flag = checkerlib.get_flag(self.cur_tick)
		username, pw, token = self.generate_account(flag, 'random-user', 'random-password', 'random-token')

		self.connect()
		self.r.recvuntil(b'>', drop=True)
		self.register(username, pw, token)
		resp = self.r.recvuntil(b'> ', drop=True)

		self.disconnect()
		if b'[!] User was created. You can use this token to reset your password' not in resp:
			return checkerlib.CheckResult.FAULTY, 'Could not register user'
		return checkerlib.CheckResult.OK, ''

	@checks.task('login', 'register')
	@ExceptionContext('error during login', CheckResult.FAULTY, toplevel=True)
	def check_login(self):
		flag = checkerlib.get_flag(self.cur_tick)
		username, pw, _ = self.generate_account(flag, 'random-user', 'random-password','')
		
		self.connect()
		self.r.recvuntil(b'>', drop=True)

		self.login(username, pw)
		
		resp = self.r.recvuntil(b'>', drop=True)
		self.disconnect()
		if resp != b' [!] You are now logged in.\n\n# [Authenticated]\n# Select an action:\n1. New note\n2. Open note\n3. Logout\n':
			return checkerlib.CheckResult.FAULTY, 'Could not login with valid credentials'

		return checkerlib.CheckResult.OK, ''

	@checks.task('logout', 'register')
	@ExceptionContext('could not logout', CheckResult.FAULTY, toplevel=True)
	def check_logout(self):
		flag = checkerlib.get_flag(self.cur_tick)
		username, pw, token = self.generate_account(flag, 'random-user', 'random-password','random-token')
	
		self.connect()

		self.r.recvuntil(b'>', drop=True)
		self.login(username, pw)

		self.r.recvuntil(b'>', drop=True)
		self.r.sendline(b'3')

		resp = self.r.recvuntil(b'>', drop=True)
		self.disconnect()

		if resp!=b' \n[!] You were logged out.\n\n# [Unauthenticated]\n# Select an action:\n1. Login\n2. Register\n3. Password Reset\n4. Exit\n':
			return checkerlib.CheckResult.FAULTY, 'Could not logout'
		return checkerlib.CheckResult.OK, ''


	@checks.task('create-note')
	@ExceptionContext('error during note creation', CheckResult.FAULTY, toplevel=True)
	def check_create_note(self):
		flag = checkerlib.get_flag(self.cur_tick)
		username, pw, token = self.generate_account(flag, 'random-user1', 'random-password1','random-token1')
		note_name, content = self.generate_note(flag, 'random-note1', 'random-content1')
		
		self.connect()
		self.r.recvuntil(b'>', drop=True)
		self.register(username, pw, token)

		self.r.recvuntil(b'>', drop=True)
		self.login(username, pw)
		
		self.r.recvuntil(b'>', drop=True)
		self.create_note(note_name, content)

		resp = self.r.recvuntil(b'>', drop=True)

		self.disconnect()
		if resp != b' [!] Your note was saved.\n\n# [Authenticated]\n# Select an action:\n1. New note\n2. Open note\n3. Logout\n':
			return checkerlib.CheckResult.FAULTY, 'Could not create note'

		return checkerlib.CheckResult.OK, ''

	@checks.task('open-note', 'create-note')
	@ExceptionContext('could not access stored note', CheckResult.FAULTY, toplevel=True)
	def check_open_note(self):
		flag = checkerlib.get_flag(self.cur_tick)
		username, pw, token = self.generate_account(flag, 'random-user1', 'random-password1','random-token1')
		note_name, content = self.generate_note(flag, 'random-note1', 'random-content1')
		
		self.connect()
		self.r.recvuntil(b'>', drop=True)
		self.register(username, pw, token)

		self.r.recvuntil(b'>', drop=True)
		self.login(username, pw)
		
		self.r.recvuntil(b'>', drop=True)
		resp = self.open_note(note_name)

		self.disconnect()
		if resp != content:
			return checkerlib.CheckResult.FAULTY, 'A note did not contain the expected content'

		return checkerlib.CheckResult.OK, ''

	@checks.task('reset-password')
	@ExceptionContext('could not reset password', CheckResult.FAULTY, toplevel=True)
	def check_password_reset(self):
		flag = checkerlib.get_flag(self.cur_tick)
		username, pw, token = self.generate_account(flag, 'reset-user', 'reset-password','reset-token')
		_, new_pw, _ = self.generate_account(flag, 'reset-user', 'new-password','reset-token')
		
		self.connect()
		self.r.recvuntil(b'>', drop=True)
		self.register(username, pw, token)
		
		self.r.recvuntil(b'>', drop=True)
		self.reset_pw(username, token, new_pw)

		self.r.recvuntil(b'>', drop=True)
		self.login(username, new_pw)

		resp = self.r.recvuntil(b'>', drop=True)
		self.disconnect()
		if resp != b' [!] You are now logged in.\n\n# [Authenticated]\n# Select an action:\n1. New note\n2. Open note\n3. Logout\n':
			return checkerlib.CheckResult.FAULTY, 'Could not login after password reset'

		return checkerlib.CheckResult.OK, ''

if __name__ == '__main__':
	checkerlib.run_check(NotescatChecker)