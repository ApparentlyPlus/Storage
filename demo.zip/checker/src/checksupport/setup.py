from setuptools import setup

setup(
    name='checksupport',
    version='1.0',
    description='A/D checker support library for ECSC2022 framework',
    author='Andrea Biondo',
    author_email='andrea@abiondo.me',
    license='MIT',
    packages=['checksupport'],
    install_requires=['ctf-gameserver'],
)
