import functools
import logging

from ctf_gameserver.checkerlib import CheckResult
from typing import Callable


class CheckerExit(Exception):
    """An exception raised to signal a checker exit.
    
    Attributes:
        result (CheckResult): The result to be returned by the checker.
        comment (str): Checker result comment.
    """

    def __init__(self, result: CheckResult, comment: str):
        super().__init__()
        self.result = result
        self.comment = comment

    def __str__(self) -> str:
        return f'check failed ({self.result}): {self.comment}'


class ExceptionContext:
    """Function decorator and context manager to convert exceptions to checker results.

    Exceptions will be logged through the logging module.

    Args:
        comment (str): Checker result comment, also used as message when logging
        exceptions.
        result (CheckResult): The result to be returned by the checker.
        toplevel (bool): If True, the decorated function will translate exceptions
        into a (CheckResult, str) return value. If False, exceptions will be wrapped
        into CheckerExit and re-raised.
    """

    def __init__(self, comment: str, result: CheckResult = CheckResult.FAULTY,
                 toplevel: bool = False):
        self._comment = comment
        self._result = result
        self._toplevel = toplevel

    def __call__(self, func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                if self._toplevel:
                    logging.exception(self._comment)
                    if isinstance(e, CheckerExit):
                        return e.result, e.comment
                    return self._result, self._comment
                else:
                    if isinstance(e, CheckerExit):
                        raise e
                    raise CheckerExit(self._result, self._comment) from e
        return wrapper

    def __enter__(self):
        assert not self._toplevel

    def __exit__(self, exc_type, exc_value, exc_tb):
        assert not self._toplevel
        if exc_value is not None:
            raise CheckerExit(self._result, self._comment) from exc_value
