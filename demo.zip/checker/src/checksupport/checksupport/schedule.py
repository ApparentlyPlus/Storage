import random

from typing import Callable, List, Tuple


class RandomScheduler:
    """A random task scheduler."""

    def __init__(self):
        self._tasks = {}

    def add_task(self, func: Callable, name: str, *deps: str, prob: float = 1.0):
        """Adds a task to the scheduler.
        
        Args:
            func (Callable): task function.
            name (str): unique task name.
            deps (str): names of tasks that this task depends on.
            prob (float): probability of scheduling the task.
        """
        assert name not in self._tasks, f'Redefined task: {name}'
        for dep in deps:
            assert dep in self._tasks, f'Unknown dependency: {dep}'
        self._tasks[name] = (func, set(deps), prob)

    def task(self, *args, **kwargs):
        """Decorator that calls add_task on the decorated function."""
        def decorator(func):
            self.add_task(func, *args, **kwargs)
            return func
        return decorator

    def schedule(self, run_all: bool = False) -> List[Tuple[str, Callable]]:
        """Produces a random schedule of task functions.
        
        Args:
            run_all (bool): If True, task probability will be ignored and
            probabilistic tasks will always be scheduled.
        """
        names = list(self._tasks.keys())
        sched = []
        processed = set()
        scheduled = set()
        have_new_scheduled = True
        while have_new_scheduled:
            have_new_scheduled = False
            random.shuffle(names)
            for name in names:
                if name in processed:
                    continue
                func, deps, prob = self._tasks[name]
                if not deps.issubset(scheduled):
                    continue
                processed.add(name)
                if run_all or random.random() < prob:
                    sched.append((name, func))
                    scheduled.add(name)
                    have_new_scheduled = True
                    break
        return sched
