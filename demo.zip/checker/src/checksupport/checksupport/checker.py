import logging

from typing import Optional, Tuple, TypeVar
from ctf_gameserver.checkerlib import BaseChecker, CheckResult

from .connection import Connectable, connected
from .exception import ExceptionContext
from .schedule import RandomScheduler


class _ConnectableChecker(BaseChecker, Connectable):
    pass


_CheckerT = TypeVar('_CheckerT', bound=BaseChecker)
_ConnectableCheckerT = TypeVar('_ConnectableCheckerT', bound=_ConnectableChecker)


class RandomChecksMixin:
    """A mixin that implements check_service() to schedule checks randomly.

    Args:
        checks (RandomScheduler): The random scheduler for check tasks. Tasks can
        optionally return Tuple[CheckResult, str]. If the CheckResult is not OK,
        checking will stop and the result will be returned by check_service().
        run_all (bool): If True, task probability will be ignored and probabilistic
        tasks will always be scheduled.
    """

    def __init__(self, checks: RandomScheduler, run_all: bool = False):
        self.__checks = checks
        self.__run_all = run_all

    def check_service(self) -> Tuple[CheckResult, str]:
        sched = self.__checks.schedule(run_all=self.__run_all)

        for i, (name, check) in enumerate(sched):
            logging.info(f'Running check task: {name}')

            ret = self.before_check(i == 0)
            if ret is not None:
                result, msg = ret
                if result != CheckResult.OK:
                    return result, msg

            ret = check(self)
            if ret is not None:
                result, msg = ret
                if result != CheckResult.OK:
                    return result, msg

            ret = self.after_check(i == len(sched)-1)
            if ret is not None:
                result, msg = ret
                if result != CheckResult.OK:
                    return result, msg

        return CheckResult.OK, ''

    def before_check(self, first: bool) -> Optional[Tuple[CheckResult, str]]:
        """Called before executing each check task. Can optionally return
        Tuple[CheckResult, str]. If the CheckResult is not OK, checking will
        stop and the result will be returned by check_service().

        Args:
            first (bool): True if called before the first task.
        """
        pass

    def after_check(self, last: bool) -> Optional[Tuple[CheckResult, str]]:
        """Called after executing each check task. Can optionally return
        Tuple[CheckResult, str]. If the CheckResult is not OK, checking will
        stop and the result will be returned by check_service().

        Args:
            last (bool): True if called after the last task.
        """
        pass


def connected_checker(cls: type[_ConnectableCheckerT]) -> type[_ConnectableCheckerT]:
    """Wraps place_flag(), check_flag(), check_service() in a Connectable class
    deriving from BaseChecker with the @connected decorator.
    """
    cls.place_flag = connected(cls.place_flag)
    cls.check_flag = connected(cls.check_flag)
    cls.check_service = connected(cls.check_service)

    return cls


def exception_checker(cls: type[_CheckerT]) -> type[_CheckerT]:
    """Wraps place_flag(), check_flag(), check_service() in a class deriving
    from BaseChecker with top-level ExceptionContext.
    
    place_flag() is wrapped in a top-level ExceptionContext with message
    "error placing flag" and result FAULTY.
    check_flag() is wrapped in a top-level ExceptionContext with message
    "error checking flag" and result FLAG_NOT_FOUND.
    check_service() is wrapped in a top-level ExceptionContext with message
    "error checking service" and result FAULTY.
    """
    cls.place_flag = ExceptionContext(
        'error placing flag',
        result=CheckResult.FAULTY,
        toplevel=True
    )(cls.place_flag)

    cls.check_flag = ExceptionContext(
        'error checking flag',
        result=CheckResult.FLAG_NOT_FOUND,
        toplevel=True
    )(cls.check_flag)

    cls.check_service = ExceptionContext(
        'error checking service',
        result=CheckResult.FAULTY,
        toplevel=True
    )(cls.check_service)

    return cls
