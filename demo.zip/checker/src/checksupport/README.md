# CheckSupport

The `checksupport` module provides several facilities to make writing checkers easier.

## Installation

1. (Optional) Create a new Python virtual environment.
2. Clone the [ECSC 2022 gameserver](https://github.com/ECSC2022/ctf-gameserver).
3. Install the gameserver by running `pip install .` from the cloned directory.
4. Install CheckSupport by running `pip install .` from this directory.

## Exception handling

The FAUST framework uses `(CheckResult, str)` return values to encode error information, and has only limited support for network I/O exceptions, which are converted to a DOWN result.
This is cumbersome, forcing checker developers to manually catch exceptions and check and propagate results from subroutines.

The `checksupport` module provides facilities to deal with exceptions in a cleaner way.

The `ExceptionContext` class is both a function decorator and a context manager, and can log and convert exceptions to checker results.
Here is an example of its functionalities:

```python
@ExceptionContext('error checking flag', CheckResult.FLAG_NOT_FOUND, toplevel=True)
def check_flag() -> Tuple[str, CheckResult]:
    connect()
    with ExceptionContext('handshake failed', CheckResult.FAULTY):
        # Perform handshake
    # [...]

@ExceptionContext('connection error', CheckResult.DOWN)
def connect():
    # Attempt connection
```

This results in the following semantics:
- If an exception occurs in `connect`, `check_service` will return `(CheckResult.DOWN, 'connection error')`.
- If an exception occurs in the `with` block, `check_service` will return `(CheckResult.FAULTY, 'handshake failed')`.
- If an exception occurs elsewhere in `check_service`, it will return `(CheckResult.FLAG_NOT_FOUND, 'error checking flag')`.

The `CheckResult` can be omitted, in which case it defaults to FAULTY (e.g., it could be omitted in the `with` block of the above example).

When used as a function decorator, `ExceptionContext` accepts the `toplevel=` boolean keyword argument, which marks a function as top-level.
A top-level function is one that returns `(CheckResult, str)`.
When an exception is raised inside an `ExceptionContext`, it is converted to a special `CheckerExit` exception which wraps the comment and `CheckResult` of the `ExceptionContext`.
It then bubbles up until it reaches a top-level context, where the `CheckerExit` exception is converted into a return value.

It is not required to mark all functions returning `(CheckResult, str)` as top-level, but there must be at least one in the call hierarchy above the point where the exception is raised.
It is generally advised to just mark the framework API boundary methods (`place_flag()`, `check_flag()`, `check_service()`) as top-level.
If you use the `exception_checker` decorator, described below, this will be handled for you.

You may manually raise `CheckerExit` (as long as you are inside some `ExceptionContext`) if you want to return a certain result without propagating return values.

The `@exception_checker` decorator can be applied on a class deriving from `BaseChecker` to decorate `place_flag()`, `check_flag()`, and `check_service()` with default top-level `ExceptionContext`s.
The following two checkers are equivalent:

```python
class Checker1(BaseChecker):
    @ExceptionContext('error placing flag', CheckResult.FAULTY, toplevel=True)
    def place_flag(self, tick: int) -> Tuple[CheckResult, str]:
        return CheckResult.OK, ''

    @ExceptionContext('error checking flag', CheckResult.FLAG_NOT_FOUND, toplevel=True)
    def check_flag(self, tick: int) -> Tuple[CheckResult, str]:
        return CheckResult.OK, ''

    @ExceptionContext('error checking service', CheckResult.FAULTY, toplevel=True)
    def check_service(self) -> Tuple[CheckResult, str]:
        return CheckResult.OK, ''


@exception_checker
class Checker2(BaseChecker):
    def place_flag(self, tick: int) -> Tuple[CheckResult, str]:
        return CheckResult.OK, ''

    def check_flag(self, tick: int) -> Tuple[CheckResult, str]:
        return CheckResult.OK, ''

    def check_service(self) -> Tuple[CheckResult, str]:
        return CheckResult.OK, ''
```

## Connection handling

The `checksupport` module provides helpers for automatic connection and disconnection.

To benefit from this, your class must implement the `Connectable` protocol by defining two methods:
- `connect()`: ensures a connection is established.
- `disconnect()`: terminates the connection if one is established.

The `@connected` decorator can be used on methods of `Connectable` classes to call `connect()` before the method and `disconnect()` afterward, regardless of whether an exception is raised by the method.

The `@connected_checker` decorator can be used on `Connectable` classes deriving from `BaseChecker` to apply `@connected` on `place_flag()`, `check_flag()`, and `check_service()`.
Here is an example that combines it with exception handling:

```python
@exception_checker
@connected_checker
class Checker(BaseChecker):
    def __init__(self, ip: str, team: int):
        super().__init__(ip, team)
        self._sock = None

    def place_flag(self, tick: int) -> Tuple[CheckResult, str]:
        self._sock.sendall(b'placing flag')
        return CheckResult.OK, ''

    def check_flag(self, tick: int) -> Tuple[CheckResult, str]:
        self._sock.sendall(b'checking flag')
        return CheckResult.OK, ''

    def check_service(self) -> Tuple[CheckResult, str]:
        self._sock.sendall(b'checking service')
        return CheckResult.OK, ''

    @ExceptionContext('connection error', CheckResult.DOWN)
    def connect(self):
        if self._sock is None:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((self.ip, 1337))
            self._sock = s

    def disconnect(self):
        if self._sock is not None:
            self._sock.close()
            self._sock = None
```

**Beware!** When using both `@exception_checker` and `@connected_checker` at the same time, the order of decorators must be as in the example above.
Otherwise, exceptions raised in `connect()` and `disconnect()` would bubble up without a top-level `ExceptionContext`.

## Random number generation

The `checksupport` module provides a `RandomGenerator` class which implements a deterministic keyed PRNG.

`RandomGenerator` exposes the usual Python `Random` interface (i.e., the standard functions from the `random` module).
On construction, you provide some entropy, usually derived from the flag and a secret.
Then, random values can be generated deterministically depending on a *key*.
Same entropy and key results in the same random sequence, even in different runs or different instances of `RandomGenerator`.

The key can be set by calling `set_key()` or through the new `key=` keyword argument accept by all methods of `Random`.
Setting the key re-seeds the PRNG deterministically.

```python
CHECKER_SECRET = 'n9oDViti1YIFnerm'

# Construct with entropy from flag + secret.
r = RandomGenerator(get_flag(tick) + CHECKER_SECRET)

ALNUM = string.ascii_letters + string.digits

# Generate a 16-character alphanumeric string with key "username".
# Option 1: explicit call to set_key()
r.set_key('username')
username = ''.join(r.choices(ALNUM, k=16))

# Generate a 16-character alphanumeric string with key "username".
# Option 2: key= keyword argument
username = ''.join(r.choices(ALNUM, k=16, key='username'))

# Generate 10 integers in [0, 100] for the key "seq".
r.set_key('seq')
seq = [r.randint(0, 100) for _ in range(10)]
# NOTE: this very different from:
#     seq = [r.randint(0, 100, key='seq') for _ in range(10)]
# Which would give you the same number repeated 10 times.
```

## Random check scheduling

The `checksupport` module provides facilities for random scheduling of SLA checks.

To take advantage of this in your checker class, you have to:

1. Create a `RandomScheduler` instance as a class variable, to which you will add your check tasks to schedule.
2. Inherit from `RandomChecksMixin`, passing the `RandomScheduler` to its constructor.
   This will provide an implementation of `check_service()` which schedules the check tasks.
   **Beware!** `RandomChecksMixin` must come before `BaseChecker` in MRO, otherwise the default `check_service()` from `BaseChecker` would be used.

The basic boilerplate, therefore, is as follows:

```python
class Checker(RandomChecksMixin, BaseChecker):
    checks = RandomScheduler()

    def __init__(self, ip: str, team: int):
        RandomChecksMixin.__init__(self, self.checks)
        BaseChecker.__init__(self, ip, team)

    def place_flag(self, tick: int) -> Tuple[CheckResult, str]:
        return CheckResult.OK, ''

    def check_flag(self, tick: int) -> Tuple[CheckResult, str]:
        return CheckResult.OK, ''

    # check_service() is provided by RandomChecksMixin
```

Tasks can be added to the `RandomScheduler` via `add_task()` or the `@task` decorator (the latter is often easier).

To define a task, you must provide a unique name for it:

```python
@checks.task('auth')
def check_auth(self):
    # Authenticate to service
    pass
```

This name can be used to make other tasks dependent on it.
You can specify as many dependencies as you like after the task name:

```python
@checks.task('func_1', 'auth')
def check_func_1(self):
    # Check functionality 1, which requires authentication
    pass
```

The scheduler guarantees that task `func_1` cannot be run until after task `auth` has been run.
Authentication is a very common example: in this case, the functionality checked by `func_1` requires authentication and therefore we specify a dependency on the `auth` task.

Tasks can be probabilistic, meaning that they will not always be run.
To create a probabilistic task, use the `prob=` keyword argument:

```python
@checks.task('func_2', 'auth', prob=0.25)
def check_func_2(self):
    # Check functionality 2, which requires authentication
    # 25% probability, i.e., 1 out of 4 runs on average
    pass
```

Now let's create a task that depends both on `func_1` and `func_2`:

```python
@checks.task('func_3', 'func_1', 'func_2')
def check_func_3(self):
    # Check functionality 3, which requires having checked 1 and 2
    pass
```

Since `func_3` depends on `func_2`, which is probabilistic, `func_3` is also probabilistic: if `func_2` is not executed, then `func_3` will not be executed either.
Therefore, in this example, `func_3` also has 25% probability.
Probabilistic tasks are independent, and therefore their joint probability in a dependency chain is the product of their individual probabilities.

Optionally, checks can return `(CheckResult, str)`.
If the `CheckResult` is not OK, then checking will stop and the result will be returned by `check_service()`.
For example:

```python
@checks.task('foo')
def check_foo(self) -> Tuple[CheckResult, str]:
    if do_something_succeeds():
        return CheckResult.OK, ''
    else:
        return CheckResult.FAULTY, 'error checking foo'
```

You can of course combine `ExceptionContext` for easy exception hadling (**pay attention to the order of decorators!**):

```python
@checks.task('foo')
@ExceptionContext('error checking foo')
def check_foo(self):
    # Check foo
    pass
```

This is convenient also because it allows you to raise `CheckerExit` instead of returning `(CheckResult, str)`.

Note that the above example assumes that `check_service()` runs with a top-level `ExceptionContext` somewhere up in the call chain, e.g., because you are using `@exception_checker` or overriding `check_service()` and calling `RandomChecksMixin.check_service()` from within an `ExceptionContext`.
If that is not the case, you can exploit the fact that tasks can optionally return `(CheckResult, str)` and use a top-level `ExceptionContext`:

```python
@checks.task('foo')
@ExceptionContext('error checking foo', toplevel=True)
def check_foo(self) -> Optional[Tuple[CheckResult, str]]:
    # Check foo
    pass
```

There also two hooks that you can override:

- `before_check(self, first: bool) -> Optional[Tuple[CheckResult, str]]`: called before every check task.
  The `first` parameter is `True` if called before the first task.
- `after_check(self, last: bool) -> Optional[Tuple[CheckResult, str]]`: called after every check task.
  The `last` parameter is `True` if called after the last task.

Both hooks can optionally return a `(CheckResult, str)`.
If the `CheckResult` is not OK, checking will stop and the result will be returned by `check_service()`.

If you require global (de)initialization, you may also override `check_service()` and call the mixin method manually.
For example:

```python
def check_service(self) -> Tuple[CheckResult, str]:
    try:
        # Do some initialization
        return RandomChecksMixin.check_service(self)
    finally:
        # Do some de-initialization
```
