import functools
import hashlib
import random

from typing import Union


class _RandomGeneratorMeta(type):
    def __new__(cls, name, bases, dct):
        typ = super().__new__(cls, name, bases, dct)
        for attr_name in random.Random.__dict__.keys():
            if attr_name.startswith('_') or attr_name in _RandomGeneratorMeta._IGNORED:
                continue
            attr_value = getattr(typ, attr_name)
            if not callable(attr_value):
                continue
            attr_value = _RandomGeneratorMeta._wrap_method(attr_value)
            setattr(typ, attr_name, attr_value)
        return typ

    @staticmethod
    def _wrap_method(method):
        @functools.wraps(method)
        def wrapper(self, *args, **kwargs):
            if 'key' in kwargs:
                self.set_key(kwargs['key'])
                del kwargs['key']
            return method(self, *args, **kwargs)
        return wrapper

    _IGNORED = {'seed', 'getstate', 'setstate'}


class RandomGenerator(random.Random, metaclass=_RandomGeneratorMeta):
    """A PRNG that can generate keyed deterministic data.

    The user shall provide entropy to the constructor. All the normal
    methods from the standard random.Random class are available. The
    set_key() method seeds the PRNG based on the provided entropy and
    the key, so that the sequence of random values generated after calls
    to set_key() with same key and initial entropy is deterministic.

    The initial state of the generator is as if set_key() had been called
    with an empty key.

    All the random generation methods from random.Random accept a new
    "key" keyword argument, which is equivalent to calling set_key()
    before invoking the random generation method.

    The implementation guarantees that if a seed-recovery attack on the
    PRNG succeeds, the attacker will not be able to recover the provided
    entropy, nor will they be able to predict random sequences for keys
    other than the one for which the attack succeeded.
    """

    def __init__(self, entropy: Union[str, bytes]):
        super().__init__()
        if isinstance(entropy, str):
            entropy = entropy.encode()
        self.__entropy = hashlib.sha256(entropy).digest()
        self.set_key('')

    def set_key(self, key: Union[str, bytes]):
        """Re-seeds the generator deterministically based on the provided key
        and the initial entropy."""
        if isinstance(key, str):
            key = key.encode()
        self.seed(hashlib.sha256(self.__entropy + key).digest())